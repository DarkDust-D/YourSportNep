class CreateTrainers < ActiveRecord::Migration[5.2]
  def change
    create_table :trainers do |t|
      t.string :nombre
      t.string :apellido
      t.integer :cedula
      t.string :direccion
      t.integer :edad
      t.string :nivel_estudios
      t.integer :experiencia

      t.timestamps
    end
  end
end
