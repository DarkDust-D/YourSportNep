Rails.application.routes.draw do
  resources :students,except:[:show]
  resources :courses, except:[:show]
  resources :departments,except:[:show]
  resources :trainers
  devise_for :users
  get 'welcome/index'
  get 'departments/getAllTrainers'
  get 'departments/getAllCourses'
  get 'departments/getTrainerDepartment'
  get 'courses/getAllMatriculaCourses'
  get 'students/enrollments'

  root 'welcome#index'
end
