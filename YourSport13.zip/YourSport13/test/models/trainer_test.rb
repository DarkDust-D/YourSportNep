require 'test_helper'

class TrainerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
